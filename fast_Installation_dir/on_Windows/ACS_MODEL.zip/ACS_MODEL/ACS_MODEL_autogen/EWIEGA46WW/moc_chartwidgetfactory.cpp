/****************************************************************************
** Meta object code from reading C++ file 'chartwidgetfactory.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../chartwidgetfactory.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'chartwidgetfactory.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSiChartWidgetENDCLASS_t {};
constexpr auto qt_meta_stringdata_CLASSiChartWidgetENDCLASS = QtMocHelpers::stringData(
    "iChartWidget",
    "signal_to_update_chart",
    "",
    "signal_to_notify_run_finished",
    "slot_to_update_chart",
    "slot_to_run_model",
    "slot_to_update_model",
    "slot_to_relise_change"
);
#else  // !QT_MOC_HAS_STRINGDATA
#error "qtmochelpers.h not found or too old."
#endif // !QT_MOC_HAS_STRINGDATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSiChartWidgetENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   50,    2, 0x06,    1 /* Public */,
       3,    0,   51,    2, 0x06,    2 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       4,    0,   52,    2, 0x08,    3 /* Private */,
       5,    0,   53,    2, 0x0a,    4 /* Public */,
       6,    0,   54,    2, 0x0a,    5 /* Public */,
       7,    0,   55,    2, 0x0a,    6 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject iChartWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_CLASSiChartWidgetENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSiChartWidgetENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSiChartWidgetENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<iChartWidget, std::true_type>,
        // method 'signal_to_update_chart'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'signal_to_notify_run_finished'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'slot_to_update_chart'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'slot_to_run_model'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'slot_to_update_model'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'slot_to_relise_change'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void iChartWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<iChartWidget *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->signal_to_update_chart(); break;
        case 1: _t->signal_to_notify_run_finished(); break;
        case 2: _t->slot_to_update_chart(); break;
        case 3: _t->slot_to_run_model(); break;
        case 4: _t->slot_to_update_model(); break;
        case 5: _t->slot_to_relise_change(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (iChartWidget::*)();
            if (_t _q_method = &iChartWidget::signal_to_update_chart; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (iChartWidget::*)();
            if (_t _q_method = &iChartWidget::signal_to_notify_run_finished; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
    }
    (void)_a;
}

const QMetaObject *iChartWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *iChartWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSiChartWidgetENDCLASS.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "iDataset_config_receiver"))
        return static_cast< iDataset_config_receiver*>(this);
    if (!strcmp(_clname, "iDataset_config_sender"))
        return static_cast< iDataset_config_sender*>(this);
    return QWidget::qt_metacast(_clname);
}

int iChartWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 6)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 6;
    }
    return _id;
}

// SIGNAL 0
void iChartWidget::signal_to_update_chart()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void iChartWidget::signal_to_notify_run_finished()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSiChartWidgetConfigENDCLASS_t {};
constexpr auto qt_meta_stringdata_CLASSiChartWidgetConfigENDCLASS = QtMocHelpers::stringData(
    "iChartWidgetConfig",
    "signal_run_model",
    "",
    "signal_model_updated",
    "signal_update_chart",
    "slot_run_model",
    "slot_apply",
    "slot_run_finished"
);
#else  // !QT_MOC_HAS_STRINGDATA
#error "qtmochelpers.h not found or too old."
#endif // !QT_MOC_HAS_STRINGDATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSiChartWidgetConfigENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   50,    2, 0x06,    1 /* Public */,
       3,    0,   51,    2, 0x06,    2 /* Public */,
       4,    0,   52,    2, 0x06,    3 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       5,    0,   53,    2, 0x08,    4 /* Private */,
       6,    0,   54,    2, 0x0a,    5 /* Public */,
       7,    0,   55,    2, 0x0a,    6 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject iChartWidgetConfig::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_CLASSiChartWidgetConfigENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSiChartWidgetConfigENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSiChartWidgetConfigENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<iChartWidgetConfig, std::true_type>,
        // method 'signal_run_model'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'signal_model_updated'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'signal_update_chart'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'slot_run_model'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'slot_apply'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'slot_run_finished'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void iChartWidgetConfig::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<iChartWidgetConfig *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->signal_run_model(); break;
        case 1: _t->signal_model_updated(); break;
        case 2: _t->signal_update_chart(); break;
        case 3: _t->slot_run_model(); break;
        case 4: _t->slot_apply(); break;
        case 5: _t->slot_run_finished(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (iChartWidgetConfig::*)();
            if (_t _q_method = &iChartWidgetConfig::signal_run_model; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (iChartWidgetConfig::*)();
            if (_t _q_method = &iChartWidgetConfig::signal_model_updated; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (iChartWidgetConfig::*)();
            if (_t _q_method = &iChartWidgetConfig::signal_update_chart; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
    }
    (void)_a;
}

const QMetaObject *iChartWidgetConfig::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *iChartWidgetConfig::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSiChartWidgetConfigENDCLASS.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "iDataset_config_sender"))
        return static_cast< iDataset_config_sender*>(this);
    return QWidget::qt_metacast(_clname);
}

int iChartWidgetConfig::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 6)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 6;
    }
    return _id;
}

// SIGNAL 0
void iChartWidgetConfig::signal_run_model()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void iChartWidgetConfig::signal_model_updated()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void iChartWidgetConfig::signal_update_chart()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}
QT_WARNING_POP
